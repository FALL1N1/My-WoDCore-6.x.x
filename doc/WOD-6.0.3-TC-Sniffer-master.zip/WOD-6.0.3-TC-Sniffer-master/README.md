WOD-6.0.3-TC-Sniffer
====================

WOD - 6.0.3 TC sniffer, orginally released on here: http://www.trinitycore.org/f/topic/9849-trinity-cores-sniffer-for-wow-603/
